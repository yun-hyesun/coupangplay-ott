
import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useProfileStore } from '../../../store/useProfileStore'
import "../scss/MySidebar.scss"

const MyMenus = [
    { id: 1, title: "내 티켓", path: "/my/ticket" },
    { id: 2, title: "내 리뷰 관리", path: "/my/review" },
    { id: 3, title: "할인 쿠폰", path: "/my/coupon" },
    { id: 4, title: "피드백 남기기", path: "/my/feedback" },
    { id: 5, title: "언어 설정", path: "/my/language" },
    { id: 6, title: "고객센터", path: "/my/support" },
    { id: 7, title: "소식 및 혜택", path: "/my/news" },
];

export const MySidebar = () => {
    const navigate = useNavigate();

    // 현재 선택된 프로필 정보
    const currentProfile = useProfileStore(
        (state) => state.currentProfile
    );

    // 프로필 전환
    const handleProfileChange = () => {
        navigate("/profiles");
    };

    return (
        <div className='my-sidebar'>
            <div className="my-profile">
                <div className="my-profile-info">

                    <div className="my-avatar">
                        <img
                            src={currentProfile?.avatar || "/images/profile/profile-img/profile.svg"}
                            alt=""
                        />
                    </div>

                    <span className="my-username">
                        {currentProfile?.name || "프로필 선택"}
                    </span>

                    <button
                        type="button"
                        className="profile-change"
                        onClick={handleProfileChange}
                    >
                        프로필 전환
                    </button>
                </div>

                <button type="button" className="my-premium"
                    onClick={() => navigate('/my/subscription')}>
                    <img
                        src="/images/mypage/premium-icon.png"
                        alt="프리미엄 패스 아이콘"
                    />
                    <img
                        src="/images/icon/DesignSystem_Icon01/icon-chevron_right.svg"
                        alt=""
                    />
                </button>
            </div>

            <nav className="my-menu" aria-label="마이페이지 메뉴">
                <ul>
                    {MyMenus.map((menu) => (
                        <li key={menu.id}>
                            <Link to={menu.path}>
                                {menu.title}
                            </Link>
                        </li>
                    ))}
                </ul>
            </nav>
        </div>
    )
}
